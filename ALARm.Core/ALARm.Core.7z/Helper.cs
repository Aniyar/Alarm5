﻿using ALARm.Core.Report;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;

using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;


namespace ALARm.Core
{
    public static class Helper
    {
        public static string GetShortForm(string name)
        {
            if (name == null)
                return "";
            name = name.ToUpper();
            string vowelsList = "АЕЁИОУЫЭЮЯ";
            string result = name.Length > 4 ? name.Substring(0, 4) : name;
            if ((result[3] == 'Ь') && (name.Length > 4))
                result += name[4];
            if (vowelsList.Contains(result[3]))
                result = result.Substring(0, 3);

            return result;
        }

        public static string GetShortFormInNormalString(string name)
        {
            name = GetShortForm(name);
            if (name.Length > 1)
                name = name[0] + name.Substring(1, name.Length - 1).ToLower();
            return name;
        }

        public static string GetResourceName(string name)
        {
            return Properties.Resources.ResourceManager.GetString(name.ToString());
        }
        public static int RoundTo10(this int digit)
        {
            int mod = digit % 10;
            return digit - mod;
            
        }
        public static int GetNextTop(this List<int> tops, int start, int top, int number)
        {
          
            for (int i = top; i < number * 100; i += 10)
            {
                if (!tops.Contains(i))
                    return i;
            }
            for (int i = top; i > start.RoundTo10(); i -= 10)
            {
                if (!tops.Contains(i))
                    return i;
            }
            return 10;

        }
        public static int GetNextTopFromBottom(this List<int> tops, int start, int top)
        {

            for (int i = start.RoundTo10() + 10; i <= (start+1)*100; i += 10)
            {
                if (!tops.Contains(i))
                    return i;
            }
            return 10;

        }
        public static Picket GetPicket(this List<Picket> pickets, int meter)
        {
            Picket result = null;
            foreach (var picket in pickets)
            {
                if ((meter / 100 + 1) == picket.Number)
                    result = picket;
            }
            if (result == null)
            {
                result = new Picket() { Number = pickets[pickets.Count - 1].Number + 1, start = pickets[pickets.Count - 1].Number * 100 };
                pickets.Add(result);
                return result;
            }
            if (!result.IsFilled)
                return result;
            
            int notFillIndex = -1;
            for (int i = pickets.IndexOf(result) - 1; i >= 0; i--)
            {
                if (!pickets[i].IsFilled)
                {
                    notFillIndex = i;
                    break;
                }
            }
            if (notFillIndex != -1)
            {
                for (int i = notFillIndex; i <= pickets.IndexOf(result); i++)
                {
                    var first = pickets[i + 1].Notes.GetFirstMove();
                    if (first != null)
                    {
                        pickets[i].Notes.Add(first);
                        pickets[i + 1].Notes.Remove(first);
                        return result;
                    }
                }
            }
            notFillIndex = -1;
            for (int i = pickets.IndexOf(result); i < pickets.Count; i++)
            {
                if (!pickets[i].IsFilled)
                {
                    notFillIndex = i;
                    break;
                }
            }
            if (notFillIndex != -1)
            {
                return pickets[notFillIndex];
            }
            result = new Picket() { Number = pickets[pickets.Count - 1].Number + 1, start = pickets[pickets.Count - 1].Number * 100 };
            pickets.Add(result);
            return result;
        }
        public static AlertNote GetFirstMove(this List<AlertNote> notes)
        {
            AlertNote result = null;
            for (int i = 0; i < notes.Count; i++)
            {
                if (!(notes[i].Note.Contains("Уст.ск:") || notes[i].Note.Contains("R")))
                {
                    result = notes[i];
                    break;
                }
            }
            return result;
        }
        public static Bitmap ToBitmap(this int[,] GreyScaleArray)
        {
            int width = GreyScaleArray.GetLength(1); // read from file
            int height = GreyScaleArray.GetLength(0); // read from file
            var bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);

            for (int x = 0; x < width; x++)
                for (int y = 0; y < height; y++)
                {
                    int red = GreyScaleArray[y, x]; // read from array
                    int green = GreyScaleArray[y, x]; // read from array
                    int blue = GreyScaleArray[y, x]; // read from array
                    bitmap.SetPixel(x, y, Color.FromArgb(0, red, green, blue));
                }
            return bitmap;
        }
        public static void SendMessageFromSocket(string ip, int port, string message)
        {
            // Буфер для входящих данных
            byte[] bytes = new byte[1024];

            // Соединяемся с удаленным устройством

            // Устанавливаем удаленную точку для сокета
            IPHostEntry ipHost = Dns.GetHostEntry(ip);
            IPAddress ipAddr = ipHost.AddressList[0];
            IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, port);

            Socket sender = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            // Соединяем сокет с удаленной точкой
            sender.Connect(ipEndPoint);


            byte[] msg = Encoding.UTF8.GetBytes(message);

            // Отправляем данные через сокет
            int bytesSent = sender.Send(msg);

            // Получаем ответ от сервера
            //int bytesRec = sender.Receive(bytes);

        //    Console.WriteLine("\nОтвет от сервера: {0}\n\n", Encoding.UTF8.GetString(bytes, 0, bytesRec));

            // Используем рекурсию для неоднократного вызова SendMessageFromSocket()
            if (message.IndexOf("<TheEnd>") == -1)
                SendMessageFromSocket(ip, port, message);

            // Освобождаем сокет
            sender.Shutdown(SocketShutdown.Both);
            sender.Close();
        }
    }
}
