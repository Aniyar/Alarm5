﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class Rfid : MainTrackObject
    {
        public int Km { get; set; }
        public int Meter { get; set; }
        public string Mark { get; set; }
    }
}
