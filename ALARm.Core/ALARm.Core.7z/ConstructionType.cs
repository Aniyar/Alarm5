﻿namespace ALARm.Core
{
    public enum ConstructionType { Bridge = 0, Tunnel =1};
}