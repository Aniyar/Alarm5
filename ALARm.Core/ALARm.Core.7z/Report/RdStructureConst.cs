﻿namespace ALARm.Core
{
    public static class RdStructureConst
    {
        public const int at = 0;
        public const int bnr = 1;
        public const int bns2 = 2;
        public const int no_bolt_styk = 3;
        public const int rail_fasteners_new = 4;
        public const int rfn2 = 5;
        public const int anti_theft_no_bolt = 6;
        public const int no_bolt_na_nakladke_shpal = 7;
        public const int nbnr = 8;
        public const int bnro = 9;
        public const int izoStyk = 10;
        public const int ls = 11;
        public const int at1 = 12;
        public const int bnr1 = 13;
        public const int bns21 = 14;
        public const int no_bolt_styk1 = 15;
        public const int rail_fasteners_new1 = 16;
        public const int rfn21 = 17;
        public const int anti_theft_no_bolt1 = 18;
        public const int no_bolt_na_nakladke_shpal1 = 19;
        public const int nbnr1 = 20;
        public const int bnro1 = 21;
        public const int izoStyk1 = 22;
        public const int ls1 = 23;
        public const int ReportCatalog = 2000;
    }
    public enum ProcessType { Gaps = 100, AdditionalParameters = 0, VideoProcess = 101 }
}
