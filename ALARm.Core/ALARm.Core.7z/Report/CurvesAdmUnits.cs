﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core.Report
{
    public class CurvesAdmUnits
    {
        public string Track { get; set; }
        public string Direction { get; set; }
        public string StationStart { get; set; }
        public string StationFinal { get; set; }
		public int Order { get; set; }
    }
}
