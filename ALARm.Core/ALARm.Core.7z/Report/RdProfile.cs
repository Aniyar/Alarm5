﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class RdProfile
    {
        public Int64 Id { get; set; }
        public Int64 Process_id { get; set; }
        public Int64 Track_id { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public double Deviation { get; set; }

        public string Direction { get; set; }
        public string Track { get; set; }
        public int Km { get {
                return X / 1000;
            } }
        public int M { get {
                return X % 1000;
            } }
    }
}
