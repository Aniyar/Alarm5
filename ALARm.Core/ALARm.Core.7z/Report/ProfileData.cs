﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Xml.Linq;

namespace ALARm.Core.Report
{
    public class StraightProfile
    {
        public int CoordAbs { get; set; }
        public int Km { get {
                return CoordAbs / 1000;
            } }
        public int M {
            get {
                return CoordAbs % 1000;
            } }
        public int Profile { get; set; }
        public int Len { get; set; }
        public double Slope { get; set; }
        public string SlopeText { get {
                return double.IsNaN(Slope)? "-" : Math.Round(Slope, 2).ToString().Replace(',', '.');
            } }
        public double SlopeDiff { get; set; }
        public string SlopeDiffText { get {
                return double.IsNaN(SlopeDiff) ? "-" : Math.Round(SlopeDiff, 2).ToString().Replace(',', '.');
            } }
    }

    public class ProfileData
    {
        public ProfileData(List<int> x, List<int> y)
        {
            X = x.ToArray();
            Y = y.ToArray();
            StraighteningProfile();

            scheme_y = 415.7;
            scheme_len = 1100;
        }

        public ProfileData(List<int> x, List<int> y, List<double> deviations)
        {
            X = x.ToArray();
            Y = y.ToArray();
            D = deviations.ToArray();
            StraighteningProfile();

            scheme_y = 340.183;
            scheme_len = 900;
        }

        private int[] X;
        private int[] Y;
        private double[] D;
        private double scheme_y = 415.7;
        private double scheme_len = 1100;

        public List<StraightProfile> straightProfiles = new List<StraightProfile>();

        public void PicketInfo(XElement xElement)
        {
            int start = straightProfiles.Min(s => s.Km) * 1000;
            int final = straightProfiles.Max(s => s.Km * 1000 + s.M);
            int startP = (straightProfiles.Min(s => s.Km * 1000 + s.M) % 1000) / 100 + 1;
            int startK = straightProfiles.Min(s => s.Km);
            int lastValue = -1;
            double x_coef = 25.0 / 5000; //x - km

            while (startK * 1000 + (startP - 1) * 100 < final)
            {
                if (X.Contains(startK * 1000 + (startP - 1) * 100))
                {
                    xElement.Add(new XElement("pickets",
                        new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("y1", 3),
                        new XAttribute("y2", 4)));

                    if (startK * 1000 + (startP - 1) * 100 - start > 15)
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", (startK * 1000 + (startP - 1) * 100 - start) * x_coef + 0.075),
                            new XAttribute("text", Y[X.ToList().IndexOf(startK * 1000 + (startP - 1) * 100)])));
                    }
                    else
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", 0.15),
                            new XAttribute("text", Y[X.ToList().IndexOf(startK * 1000 + (startP - 1) * 100)])));
                    }

                    if (lastValue != -1)
                    {
                        if (lastValue > Y[X.ToList().IndexOf(startK * 1000 + (startP - 1) * 100)])
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                        else
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                    }

                    lastValue = Y[X.ToList().IndexOf(startK * 1000 + (startP - 1) * 100)];
                }
                else if (X.ToList().Where(x => x - startK * 1000 + (startP - 1) * 100 >= -10 && x - startK * 1000 + (startP - 1) * 100 <= 10).Any())
                {
                    int x_temp = X.ToList().Where(x => x - startK * 1000 + (startP - 1) * 100 >= -10 && x - startK * 1000 + (startP - 1) * 100 <= 10).First();

                    xElement.Add(new XElement("pickets",
                        new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("y1", 3),
                        new XAttribute("y2", 4)));

                    if (startK * 1000 + (startP - 1) * 100 - start > 15)
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", (startK * 1000 + (startP - 1) * 100 - start) * x_coef + 0.075),
                            new XAttribute("text", Y[X.ToList().IndexOf(x_temp)])));
                    }
                    else
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", 0.15),
                            new XAttribute("text", Y[X.ToList().IndexOf(x_temp)])));
                    }

                    if (lastValue != -1)
                    {
                        if (lastValue > Y[X.ToList().IndexOf(x_temp)])
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                        else
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                    }

                    lastValue = Y[X.ToList().IndexOf(x_temp)];
                }
                else
                {
                    int x1 = X.ToList().Where(x => x - startK * 1000 + (startP - 1) * 100 >= 0).First();
                    int x2 = X.ToList().Where(x => startK * 1000 + (startP - 1) * 100 - x >= 0).Last();
                    int y1 = Y[X.ToList().IndexOf(x1)];
                    int y2 = Y[X.ToList().IndexOf(x2)];
                    int y = (y2 - y1) * (startK * 1000 + (startP - 1) * 100 - x1) / (x2 - x1) + y1;

                    xElement.Add(new XElement("pickets",
                        new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                        new XAttribute("y1", 3),
                        new XAttribute("y2", 4)));

                    if (startK * 1000 + (startP - 1) * 100 - start > 15)
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", (startK * 1000 + (startP - 1) * 100 - start) * x_coef + 0.075),
                            new XAttribute("text", y)));
                    }
                    else
                    {
                        xElement.Add(new XElement("pickets_value",
                            new XAttribute("x", -2.98),
                            new XAttribute("y", 0.15),
                            new XAttribute("text", y)));
                    }

                    if (lastValue != -1)
                    {
                        if (lastValue > y)
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                        else
                        {
                            xElement.Add(new XElement("pickets",
                                new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                                new XAttribute("x2", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                                new XAttribute("y1", 3),
                                new XAttribute("y2", 4)));
                        }
                    }

                    lastValue = y;
                }

                startP++;
                if (startP > 10)
                {
                    startK++;
                    startP -= 10;
                }
            }

            xElement.Add(new XElement("pickets",
                new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                new XAttribute("y1", 3),
                new XAttribute("y2", 4)));
            xElement.Add(new XElement("pickets_value",
                new XAttribute("x", -2.98),
                new XAttribute("y", 24.95),
                new XAttribute("text", Y[X.ToList().IndexOf(final)])));
            if (lastValue > Y[X.ToList().IndexOf(final)])
            {
                xElement.Add(new XElement("pickets",
                    new XAttribute("x1", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                    new XAttribute("x2", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                    new XAttribute("y1", 3),
                    new XAttribute("y2", 4)));
            }
            else
            {
                xElement.Add(new XElement("pickets",
                    new XAttribute("x1", (startK * 1000 + (startP - 1) * 100 - start) * x_coef),
                    new XAttribute("x2", (startK * 1000 + (startP - 2) * 100 - start) * x_coef),
                    new XAttribute("y1", 3),
                    new XAttribute("y2", 4)));
            }
        }

        public void StraightInfo(XElement xElement)
        {
            int start = straightProfiles.Min(s => s.Km) * 1000;
            double x_coef = 25.0 / 5000; //x - km

            for (int i = 0; i < straightProfiles.Count - 1; i++)
            {
                xElement.Add(new XElement("straights",
                    new XAttribute("x1", (straightProfiles[i].CoordAbs - start) * x_coef),
                    new XAttribute("x2", (straightProfiles[i].CoordAbs - start) * x_coef),
                    new XAttribute("y1", 1),
                    new XAttribute("y2", 2)));

                if (straightProfiles[i].Profile > straightProfiles[i + 1].Profile)
                {
                    xElement.Add(new XElement("straights",
                        new XAttribute("x1", (straightProfiles[i].CoordAbs - start) * x_coef),
                        new XAttribute("x2", (straightProfiles[i + 1].CoordAbs - start) * x_coef),
                        new XAttribute("y1", 1),
                        new XAttribute("y2", 2)));
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", (straightProfiles[i + 1].CoordAbs - start) * x_coef - straightProfiles[i].Slope.ToString("0.##").Length * 0.11),
                        new XAttribute("y", 1.2),
                        new XAttribute("rotate", 0),
                        new XAttribute("text", straightProfiles[i].Slope.ToString("0.##").Replace(',', '.'))));
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", (straightProfiles[i].CoordAbs - start) * x_coef + 0.01),
                        new XAttribute("y", 1.95),
                        new XAttribute("rotate", 0),
                        new XAttribute("text", straightProfiles[i].Len)));
                }
                else
                {
                    xElement.Add(new XElement("straights",
                        new XAttribute("x2", (straightProfiles[i].CoordAbs - start) * x_coef),
                        new XAttribute("x1", (straightProfiles[i + 1].CoordAbs - start) * x_coef),
                        new XAttribute("y1", 1),
                        new XAttribute("y2", 2)));
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", (straightProfiles[i].CoordAbs - start) * x_coef + 0.01),
                        new XAttribute("y", 1.2),
                        new XAttribute("rotate", 0),
                        new XAttribute("text", straightProfiles[i].Slope.ToString("0.##").Replace(',', '.'))));
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", (straightProfiles[i + 1].CoordAbs - start) * x_coef - straightProfiles[i].Len.ToString().Length * 0.11),
                        new XAttribute("y", 1.95),
                        new XAttribute("rotate", 0),
                        new XAttribute("text", straightProfiles[i].Len)));
                }
                
                if (straightProfiles[i].CoordAbs - start < 15)
                {
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", -0.95),
                        new XAttribute("y", 0.15),
                        new XAttribute("rotate", 270),
                        new XAttribute("text", straightProfiles[i].Profile)));
                }
                else
                {
                    xElement.Add(new XElement("straights_value",
                        new XAttribute("x", -0.95),
                        new XAttribute("y", (straightProfiles[i].CoordAbs - start) * x_coef + 0.075),
                        new XAttribute("rotate", 270),
                        new XAttribute("text", straightProfiles[i].Profile)));
                }
            }

            if (straightProfiles.Last().CoordAbs - start > 4950)
            {
                xElement.Add(new XElement("straights",
                    new XAttribute("x1", (straightProfiles.Last().CoordAbs - start) * x_coef),
                    new XAttribute("x2", (straightProfiles.Last().CoordAbs - start) * x_coef),
                    new XAttribute("y1", 1),
                    new XAttribute("y2", 2)));
                xElement.Add(new XElement("straights_value",
                    new XAttribute("x", -0.95),
                    new XAttribute("y", 24.95),
                    new XAttribute("rotate", 270),
                    new XAttribute("text", straightProfiles.Last().Profile)));
            }
            else
            {
                xElement.Add(new XElement("straights",
                    new XAttribute("x1", (straightProfiles.Last().CoordAbs - start) * x_coef),
                    new XAttribute("x2", (straightProfiles.Last().CoordAbs - start) * x_coef),
                    new XAttribute("y1", 1),
                    new XAttribute("y2", 2)));
                xElement.Add(new XElement("straights_value",
                    new XAttribute("x", -0.95),
                    new XAttribute("y", (straightProfiles.Last().CoordAbs - start) * x_coef + 0.075),
                    new XAttribute("rotate", 270),
                    new XAttribute("text", straightProfiles.Last().Profile)));
            }
        }

        public string GraphProfile()
        {
            int start = (X.Min() / 1000) * 1000;
            double x_coef = 944.9 / 5000, y_coef = scheme_y / scheme_len; //x - km, y - sm
            string graph = "";

            for (int i = 0; i < X.Length; i++)
            {
                graph += ((X[i] - start) * x_coef).ToString("0.####").Replace(',', '.') + ",";
                graph += (scheme_y - (Y[i] % scheme_len) * y_coef).ToString("0.####").Replace(',', '.') + " ";
            }

            return graph;
        }

        public string GraphStraightProfile()
        {
            int start = straightProfiles.Min(s => s.Km) * 1000;
            double x_coef = 944.9 / 5000, y_coef = scheme_y / scheme_len; //x - km, y - sm
            string graph = "";

            for (int i = 0; i < straightProfiles.Count; i++)
            {
                if (i != 0)
                {
                    if (straightProfiles[i].Profile / scheme_len != straightProfiles[i - 1].Profile / scheme_len)
                    {
                        if (straightProfiles[i].Profile / scheme_len > straightProfiles[i - 1].Profile / scheme_len)
                        {
                            double x_temp = (straightProfiles[i].CoordAbs - straightProfiles[i - 1].CoordAbs) / (straightProfiles[i].Profile % scheme_len + scheme_len - straightProfiles[i - 1].Profile % scheme_len) * (scheme_len - straightProfiles[i - 1].Profile % scheme_len) + straightProfiles[i - 1].CoordAbs - start;
                            graph += (x_temp * x_coef).ToString("0.####").Replace(',', '.') + ",";
                            graph += (scheme_len * y_coef).ToString("0.####").Replace(',', '.') + " ";
                            graph += (x_temp * x_coef).ToString("0.####").Replace(',', '.') + ",";
                            graph += (0 * y_coef).ToString("0.####").Replace(',', '.') + " ";
                        }
                        else
                        {
                            double x_temp = (straightProfiles[i].CoordAbs - straightProfiles[i - 1].CoordAbs) / (straightProfiles[i].Profile % scheme_len - straightProfiles[i - 1].Profile % scheme_len - scheme_len) * ((-1.0) * straightProfiles[i - 1].Profile % scheme_len) + straightProfiles[i - 1].CoordAbs - start;
                            graph += (x_temp * x_coef).ToString("0.####").Replace(',', '.') + ",";
                            graph += (0 * y_coef).ToString("0.####").Replace(',', '.') + " ";
                            graph += (x_temp * x_coef).ToString("0.####").Replace(',', '.') + ",";
                            graph += (scheme_len * y_coef).ToString("0.####").Replace(',', '.') + " ";
                        }
                    }
                }

                graph += ((straightProfiles[i].CoordAbs - start) * x_coef).ToString("0.####").Replace(',', '.') + ",";
                graph += (scheme_y - (straightProfiles[i].Profile % scheme_len) * y_coef).ToString("0.####").Replace(',', '.') + " ";
            }

            return graph;
        }

        public string GraphDeviation()
        {
            int start = (X.Min() / 1000) * 1000;
            double x_coef = 944.9 / 5000, y_coef = 37.8167 / 10; //x - km, y - sm
            string graph = "";

            for (int i = 0; i < X.Length; i++)
            {
                graph += ((X[i] - start) * x_coef).ToString("0.####").Replace(',', '.') + ",";
                graph += ((scheme_y + 113.417 / 2) - D[i] * y_coef).ToString("0.####").Replace(',', '.') + " ";
            }

            return graph;
        }

        private void StraighteningProfile()
        {
            straightProfiles.Add(new StraightProfile {
                CoordAbs = X[0],
                Profile = Y[0],
                SlopeDiff = double.NaN
            });
            int i = 0;

            for (int j = 1; j < X.Length; j++)
            {
                double Bx = X[j] - X[i], By = Y[j] - Y[i];
                for (int k = i + 1; k < j - 1; k++)
                {
                    double maxDistance = (Y[k] - Y[i]) - By / Bx * (X[k] - X[i]);                        
                    if (Math.Abs(maxDistance) > 50.0)
                    {
                        var tempSP = straightProfiles.Last();
                        tempSP.Len = X[j - 1] - tempSP.CoordAbs;
                        tempSP.Slope = Convert.ToDouble(Y[j - 1] - tempSP.Profile) * 10 / tempSP.Len;

                        straightProfiles.Add(new StraightProfile {
                            CoordAbs = X[j - 1],
                            Profile = Y[j - 1]
                        });

                        i = j - 1;
                        break;
                    }
                }
            }

            if (!straightProfiles.Where(s => s.CoordAbs == X.Last() && s.Profile == Y.Last()).Any())
            {
                var tempSP = straightProfiles.Last();
                tempSP.Len = X.Last() - tempSP.CoordAbs;
                tempSP.Slope = Convert.ToDouble(Y.Last() - tempSP.Profile) * 10 / tempSP.Len;

                straightProfiles.Add(new StraightProfile {
                    CoordAbs = X.Last(),
                    Profile = Y.Last(),
                    Len = 0,
                    Slope = double.NaN,
                    SlopeDiff = double.NaN
                });
            }

            for (i = 1; i < straightProfiles.Count - 1; i++)
            {
                straightProfiles[i].SlopeDiff = straightProfiles[i].Slope - straightProfiles[i - 1].Slope;
            }
        }
    }
}
