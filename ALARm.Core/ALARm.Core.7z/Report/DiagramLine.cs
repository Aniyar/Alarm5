﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core.Report
{
    public enum DiagramLine
    {
        Gauge = 0, ZeroGauge = 1
    }
}
