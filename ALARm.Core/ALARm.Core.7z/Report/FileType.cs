﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core.Report
{
    public enum FileType
    {
        VideoObjects = 1,
        RailProfile = 2,
        SleeperProfile = 3,
        VideoMonitoring

    }
}
