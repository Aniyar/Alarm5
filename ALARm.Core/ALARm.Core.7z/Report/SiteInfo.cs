﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class SiteInfo
    {
        public string StationStart { get; set; }
        public int St1 { get; set; }
        public string StationFinal { get; set; }
        public int St2 { get; set; }
    }
}
