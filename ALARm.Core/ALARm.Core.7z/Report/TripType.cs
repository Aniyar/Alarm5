﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core.Report
{
    public enum TripType
    {
        Work = 0 , Control = 1 , Additional = 2
    }
}
