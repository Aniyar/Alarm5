﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core.Report
{
    public class RdObject
    {
        public long ID { get; }
        public int Meter { get; set; }
        public int Km { get; set; }
        public long track_id { get; set; }
        
    }

   
}
