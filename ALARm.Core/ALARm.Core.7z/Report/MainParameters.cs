﻿

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

using System.Xml;
using System.Xml.Linq;
using System.Xml.Xsl;
using ALARm.Core;
using System.Drawing.Printing;
using Svg;
using System.Drawing;

namespace ALARm.Core.Report
{
    public class MainParameters : GraphicDiagrams
    {
        private float LevelPosition = 32.5f;
        private float LevelStep = 7.5f;
        private float LevelKoef = 0.25f;

        private float StraighRighttPosition = 62f;
        private float StrightStep = 15f;
        private float StrightKoef = 0.5f;

        private float GaugeKoef = 0.5f;
        private float ProsKoef = 0.5f;

        private float StrightLeftPosition = 71f;

        private float GaugePosition = 100.5f;

        private float ProsRightPosition = 124.5f;

        private float ProsLeftPosition = 138.5f;




        public MainParameters(IRdStructureRepository rdStructureRepository, IMainTrackStructureRepository mainTrackStructureRepository, IAdmStructureRepository admStructureRepository)
        {
            this.RdStructureService = rdStructureRepository;
            this.MainTrackStructureService = mainTrackStructureRepository;
            this.AdmStructureService = admStructureRepository;
        }


        public void Process(ReportTemplate template, Kilometer kilometer, Trips trip, bool autoprint)
        {

            diagramName = "Оригинал";
            XDocument htReport = new XDocument();
            var svgLength = 0;
            using (XmlWriter writer = htReport.CreateWriter())
            {
                //float koef = 3.5f / 0.6f;
                XDocument xdReport = new XDocument();
                XElement report = new XElement("report");

                int svgIndex = template.Xsl.IndexOf("</svg>");
                template.Xsl = template.Xsl.Insert(svgIndex, righstSideXslt());

                var xml = XDocument.Load($@"G:\work_shifrovka\{kilometer.Number}_{ kilometer.Track_id}.xml");
                List<float> prosLeft = xml.Root.Element("prosleft").Elements("pr").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> prosRight = xml.Root.Element("prosright").Elements("pr").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> fsh0 = xml.Root.Element("fsh0").Elements("sh0").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> fsh = xml.Root.Element("fsh").Elements("sh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> fsr_rh1 = xml.Root.Element("fsr_rh1").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> frih1 = xml.Root.Element("frih1").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> frih10 = xml.Root.Element("frih10").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> fsr_rh2 = xml.Root.Element("fsr_rh2").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> frih2 = xml.Root.Element("frih2").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> frih20 = xml.Root.Element("frih20").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> fsr_urb = xml.Root.Element("fsr_urb").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> furb = xml.Root.Element("furb").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> furb0 = xml.Root.Element("furb0").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<float> piketspeed = xml.Root.Elements("piketspeed").Select(x => (float)Convert.ToDouble(x.Value.Replace(",", "."))).ToList();
                List<int> fmeter = xml.Root.Element("meter").Elements("m").Select(x => Convert.ToInt32(x.Value.Replace(",", "."))).ToList();
                List<int> strights = xml.Root.Element("straightening").Elements("s").Select(x => Convert.ToInt32(x.Value.Replace(",", "."))).ToList();
                var common = xml.Root.Attribute("common").Value;
                var averagespeed = xml.Root.Attribute("averagespeed").Value;
                var speedlimit = xml.Root.Attribute("speedlimit").Value;

                //"У(2, 0, 0) П(7, 0, 2) Р(4, 0, 0) C(11, 0, 0) Уш(22, 0, 0) Пр(14, 0, 0) "
                //   0          3          6           9           12           15
                //common.Replace(" ", "   ");
                //common.Split(' ')[0];

                common = common.Replace("У", "");
                common = common.Replace("П", "");
                common = common.Replace("Р", "");
                common = common.Replace("C", "");
                common = common.Replace("ш", "");
                common = common.Replace("р", "");
                common = common.Replace("(", "");
                common = common.Replace(")", ",");
                common = common.Replace(" ", "");
                int secondSt = Convert.ToInt32(common.Split(',')[0]) + Convert.ToInt32(common.Split(',')[3]) + Convert.ToInt32(common.Split(',')[6]) + Convert.ToInt32(common.Split(',')[9]) + Convert.ToInt32(common.Split(',')[12]) + Convert.ToInt32(common.Split(',')[15]);
                int thirdSt = Convert.ToInt32(common.Split(',')[1]) + Convert.ToInt32(common.Split(',')[4]) + Convert.ToInt32(common.Split(',')[7]) + Convert.ToInt32(common.Split(',')[10]) + Convert.ToInt32(common.Split(',')[13]) + Convert.ToInt32(common.Split(',')[16]);
                int fourSt = Convert.ToInt32(common.Split(',')[2]) + Convert.ToInt32(common.Split(',')[5]) + Convert.ToInt32(common.Split(',')[8]) + Convert.ToInt32(common.Split(',')[11]) + Convert.ToInt32(common.Split(',')[14]) + Convert.ToInt32(common.Split(',')[17]);
                common = "Кол.ст.-2:" + secondSt + "; 3:" + thirdSt + "; 4:" + fourSt;

                var limit = xml.Root.Attribute("speedlimit").Value;

                List<AlertNote> notes = (from note in xml.Root.Element("notes").Elements("note")
                                         select new AlertNote()
                                         {
                                             Note = (string)note.Attribute("note"),
                                             Top = (int)note.Attribute("top"),
                                             FontStyle = (int)note.Attribute("fstyle")
                                         }).ToList();

                notes = notes.OrderBy(note => note.Top).ToList();



                //tripProcess.Direction = Direction.Direct;
                string drawdownRight = string.Empty, drawdownLeft = string.Empty, gauge = string.Empty, zeroGauge = string.Empty,
                        zeroStraighteningRight = string.Empty, averageStraighteningRight = string.Empty, straighteningRight = string.Empty,
                        zeroStraighteningLeft = string.Empty, averageStraighteningLeft = string.Empty, straighteningLeft = string.Empty,
                        level = string.Empty, averageLevel = string.Empty, zeroLevel = string.Empty;




                var speed = MainTrackStructureService.GetMtoObjectsByCoord(trip.Trip_date, kilometer.Number,
                    MainTrackStructureConst.MtoSpeed, kilometer.Track_id) as List<Speed>;
                var fragment = MainTrackStructureService.GetMtoObjectsByCoord(trip.Trip_date, kilometer.Number,
                    MainTrackStructureConst.Fragments, kilometer.Track_id) as Fragment;

                var sector = MainTrackStructureService.GetSector(kilometer.Track_id, kilometer.Number, trip.Trip_date);
                var station_section = MainTrackStructureService.GetMtoObjectsByCoord(trip.Trip_date, kilometer.Number, MainTrackStructureConst.MtoStationSection, kilometer.Track_id) as List<StationSection>;
                var station = xml.Root.Attribute("station").Value;



                var pdbSection = MainTrackStructureService.GetMtoObjectsByCoord(trip.Trip_date, kilometer.Number,
                    MainTrackStructureConst.MtoPdbSection, kilometer.Track_id) as List<PdbSection>;
                int fourStepOgrCoun = 0, otherfourStepOgrCoun = 0;
                var xp = kilometer.Start_m + 1;
                svgLength = kilometer.GetLength() < 1000 ? 1000 : kilometer.GetLength();
                var direction = AdmStructureService.GetDirectionByTrack(kilometer.Track_id);
                XElement addParam = new XElement("addparam",
                    new XAttribute("top-title",
                        (direction != null ? $"{direction.Name} ({direction.Code} )" : "Неизвестный") + " Путь: " + kilometer.Track_name + " Км:" +
                        kilometer.Number + " " + (pdbSection.Count > 0 ? pdbSection[0].ToString() : " ПЧ-/ПЧУ-/ПД-/ПДБ-") + " Уст: " + " " + (speed.Count > 0 ? speed[0].ToString() : "-/-/-") + " Скор:58"),
                    new XAttribute("common", common),
                    new XAttribute("right-title",
                        copyright + ": " + "ПО " + softVersion + "  " +
                        systemName + ":" + trip.Car + "(" + trip.Chief + ") (БПД от " + MainTrackStructureService.GetModificationDate() + ") <" + "КАЗ" + ">" + "<" + DateTime.Now.ToString("dd.MM.yyyy  HH:mm") + ">" +
                        "<" + Helper.GetShortFormInNormalString(Helper.GetResourceName(trip.Travel_Direction.ToString())) + ">" +
                        "<" + Helper.GetShortFormInNormalString(Helper.GetResourceName(trip.Car_Position.ToString())) + ">" +
                        "<" + trip.Trip_date.Month + "-" + trip.Trip_date.Year + " " + "контр. Проезд:" + trip.Trip_date.ToString("dd.MM.yyyy  HH:mm") + " " + diagramName + ">"
                        ),
                    new XAttribute("pre", xp + 30),
                    new XAttribute("prer", xp + 21),
                    new XAttribute("topr", -kilometer.Start_m - svgLength - 45),
                    new XAttribute("topf", xp +10 ),
                    new XAttribute("topx",-kilometer.Start_m - svgLength),
                    new XAttribute("topx1", -kilometer.Start_m - svgLength-30),
                    new XAttribute("topx2", -kilometer.Start_m - svgLength - 15),
                    new XAttribute("fragment", (station.ToString() != "" ? "Станция: " + station.ToString() : sector.ToString()) + " Км:" + kilometer.Number),
                    new XAttribute("viewbox", $"-20 {-kilometer.Start_m - svgLength-50} 820 {svgLength + 105}"),
                    new XAttribute("minY", -kilometer.Start_m),
                    new XAttribute("maxY", -kilometer.Final_m),
                    RightSideChart(trip.Trip_date, kilometer, trip.Travel_Direction, kilometer.Track_id, new float[] { 151f, 146f, 152.5f, 155f }, strights, fmeter),

                    new XElement("xgrid",
                        new XElement("x", MMToPixelChartString(LevelPosition - LevelStep), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "  –30"), new XAttribute("y", MMToPixelChartString(LevelPosition - LevelStep - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(LevelPosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "      0"), new XAttribute("y", MMToPixelChartString(LevelPosition - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(LevelPosition + LevelStep), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "    30"), new XAttribute("y", MMToPixelChartString(LevelPosition + LevelStep - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StraighRighttPosition - StrightStep), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "  –30"), new XAttribute("y", MMToPixelChartString(StraighRighttPosition - StrightStep - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StraighRighttPosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "      0"), new XAttribute("y", MMToPixelChartString(StraighRighttPosition - 1f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StraighRighttPosition + StrightStep / 10f), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "      3"), new XAttribute("y", MMToPixelChartString(StraighRighttPosition + StrightStep / 10f + 0.2f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StrightLeftPosition - StrightStep / 10f), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "    –3"), new XAttribute("y", MMToPixelChartString(StrightLeftPosition - StrightStep / 10f - 1f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StrightLeftPosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "      0"), new XAttribute("y", MMToPixelChartString(StrightLeftPosition + 0.2f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(StrightLeftPosition + StrightStep), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "    30"), new XAttribute("y", MMToPixelChartString(StrightLeftPosition + StrightStep - 0.5f)), new XAttribute("x", xp+15)),

                        new XElement("x", MMToPixelChartString(GaugePosition - 10 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey")),
                        new XElement("x", MMToPixelChartString(GaugePosition - 8 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "1512"), new XAttribute("y", MMToPixelChartString(GaugePosition - 8 * GaugeKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(GaugePosition - 4 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey")),
                        new XElement("x", MMToPixelChartString(GaugePosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "1520"), new XAttribute("y", MMToPixelChartString(GaugePosition - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(GaugePosition + 8 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "1528"), new XAttribute("y", MMToPixelChartString(GaugePosition + 8 * GaugeKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(GaugePosition + 16 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "1536"), new XAttribute("y", MMToPixelChartString(GaugePosition + 16 * GaugeKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(GaugePosition + 22 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "1542"), new XAttribute("y", MMToPixelChartString(GaugePosition + 22 * GaugeKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(GaugePosition + 26 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey")),
                        new XElement("x", MMToPixelChartString(GaugePosition + 28 * GaugeKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "1548"), new XAttribute("y", MMToPixelChartString(GaugePosition + 28 * GaugeKoef - 0.5f)), new XAttribute("x", xp+15)),

                        new XElement("x", MMToPixelChartString(ProsRightPosition - 10 * ProsKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "  –10"), new XAttribute("y", MMToPixelChartString(ProsRightPosition - 10 * ProsKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(ProsRightPosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "      0"), new XAttribute("y", MMToPixelChartString(ProsRightPosition - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(ProsRightPosition + 10 * ProsKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "    10"), new XAttribute("y", MMToPixelChartString(ProsRightPosition + 10 * ProsKoef - 0.5f)), new XAttribute("x", xp+15)),

                        new XElement("x", MMToPixelChartString(ProsLeftPosition - 10 * ProsKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "  –10"), new XAttribute("y", MMToPixelChartString(ProsLeftPosition - 10 * ProsKoef - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(ProsLeftPosition), new XAttribute("dasharray", "3,3"), new XAttribute("stroke", "black"), new XAttribute("label", "      0"), new XAttribute("y", MMToPixelChartString(ProsLeftPosition - 0.5f)), new XAttribute("x", xp+15)),
                        new XElement("x", MMToPixelChartString(ProsLeftPosition + 10 * ProsKoef), new XAttribute("dasharray", "0.5,2"), new XAttribute("stroke", "grey"), new XAttribute("label", "    10"), new XAttribute("y", MMToPixelChartString(ProsLeftPosition + 10 * ProsKoef - 0.5f)), new XAttribute("x", xp+15))
                        ));

                //kilometer._Kupe.
                for (int index = 0; index < prosRight.Count; index++)
                {
                    int metre = -fmeter[index];
                    drawdownRight += MMToPixelChartString(prosLeft[index] * ProsKoef + ProsRightPosition) + "," + metre + " ";
                    drawdownLeft += MMToPixelChartString(prosRight[index] * ProsKoef + ProsLeftPosition) + "," + metre + " ";
                    gauge += MMToPixelChartString((fsh[index] - fsh0[index]) * GaugeKoef + GaugePosition) + "," + metre + " ";
                    zeroGauge += MMToPixelChartString((fsh0[index] - 1520) * GaugeKoef + GaugePosition) + "," + metre + " ";

                    zeroStraighteningRight += MMToPixelChartString(frih20[index] * StrightKoef + StraighRighttPosition) + "," + metre + " ";
                    averageStraighteningRight += MMToPixelChartString(fsr_rh2[index] * StrightKoef + StraighRighttPosition) + "," + metre + " ";
                    straighteningRight += MMToPixelChartString(frih2[index] * StrightKoef + StraighRighttPosition) + "," + metre + " ";

                    zeroStraighteningLeft += MMToPixelChartString(frih10[index] * StrightKoef + StrightLeftPosition) + "," + metre + " ";
                    averageStraighteningLeft += MMToPixelChartString(fsr_rh1[index] * StrightKoef + StrightLeftPosition) + "," + metre + " ";
                    straighteningLeft += MMToPixelChartString(frih1[index] * StrightKoef + StrightLeftPosition) + "," + metre + " ";

                    level += MMToPixelChartString(furb[index] * LevelKoef + LevelPosition) + "," + metre + " ";
                    averageLevel += MMToPixelChartString(fsr_urb[index] * LevelKoef + LevelPosition) + "," + metre + " ";
                    zeroLevel += MMToPixelChartString(furb0[index] * LevelKoef + LevelPosition) + "," + metre + " ";
                }

                addParam.Add(new XElement("polyline", new XAttribute("points", drawdownRight)));
                addParam.Add(new XElement("polyline", new XAttribute("points", drawdownLeft)));
                addParam.Add(new XElement("polyline", new XAttribute("points", gauge)));
                addParam.Add(new XElement("polyline", new XAttribute("points", zeroGauge)));
                addParam.Add(new XElement("polyline", new XAttribute("points", zeroStraighteningRight)));
                addParam.Add(new XElement("polyline", new XAttribute("points", averageStraighteningRight)));
                addParam.Add(new XElement("polyline", new XAttribute("points", straighteningRight)));
                addParam.Add(new XElement("polyline", new XAttribute("points", zeroStraighteningLeft)));
                addParam.Add(new XElement("polyline", new XAttribute("points", averageStraighteningLeft)));
                addParam.Add(new XElement("polyline", new XAttribute("points", straighteningLeft)));
                addParam.Add(new XElement("polyline", new XAttribute("points", level)));
                addParam.Add(new XElement("polyline", new XAttribute("points", averageLevel)));
                addParam.Add(new XElement("polyline", new XAttribute("points", zeroLevel)));

                char separator = CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalSeparator[0];



                var digElemenets = new XElement("digressions");
                List<int> usedTops = new List<int>();
                List<int> speedmetres = new List<int>();

                List<Picket> pickets = new List<Picket>();
                for (int p = (kilometer.Start_m / 100) + 1; p <= kilometer.Final_m / 100; p++)
                {
                    pickets.Add(new Picket() { Number = p, start = (kilometer.Start_m / 100) + 1 == p ? kilometer.Start_m.RoundTo10() : (p - 1) * 100 });


                }
                var notMoveAlertNote = notes.Where(note => note.Note.Contains("Уст.ск:") || note.Note.Contains("R:")).ToList();
                if (station_section.Count > 0)
                {
                    if (station_section[0].Start_Km == kilometer.Number)
                    {
                        sector = MainTrackStructureService.GetSector(kilometer.Track_id, kilometer.Number-1, trip.Trip_date);
                        notMoveAlertNote.Add(new AlertNote() { NotMoving = true, Top = station_section[0].Start_M, Note = $"       {sector};{station_section[0].Start_M} Станция: {station_section[0].Station}" }) ;
                    }
                    else
                    if (station_section[0].Final_Km == kilometer.Number)
                    {
                        sector = MainTrackStructureService.GetSector(kilometer.Track_id, kilometer.Number+1, trip.Trip_date);
                        notMoveAlertNote.Add(new AlertNote() { NotMoving = true, Top = station_section[0].Final_M, Note = $"{station_section[0].Final_M} Станция: {station_section[0].Station};       {sector}" });
                    }
                }

                foreach (var note in notMoveAlertNote)
                {
                    var picket = pickets.GetPicket(note.Top);
                    picket.Notes.Add(note);
                    notes.Remove(note);
                }
                foreach (var note in notes)
                {
                    var picket = pickets.GetPicket(note.Top);
                    if (picket!= null)
                        picket.Notes.Add(note);
                }
                
                var gmeter = kilometer.Start_m.RoundTo10()+10;
                
                foreach (var picket in pickets)
                {
                    picket.WriteNotesToReport(kilometer, speedmetres, addParam, digElemenets, xml, ProsRightPosition, ProsLeftPosition, StraighRighttPosition, StrightLeftPosition, GaugePosition, LevelPosition, trip.Travel_Direction, strights,fmeter, this,ref fourStepOgrCoun,ref otherfourStepOgrCoun);
                }


                limit = limit + "/" + limit.Split('/')[1];
                addParam.Add(
                    new XAttribute("speedlimit",common + " Огр: " + limit + "  Кол.огр.:" + fourStepOgrCoun + "/" + otherfourStepOgrCoun)
                    );

                addParam.Add(digElemenets);
                report.Add(addParam);

                xdReport.Add(report);

                XslCompiledTransform transform = new XslCompiledTransform();
                transform.Load(XmlReader.Create(new StringReader(template.Xsl)));
                transform.Transform(xdReport.CreateReader(), writer);

            }
            try
            {
                htReport.Save($@"g:\form\{kilometer.Number}_{kilometer.Track_id}.html");
                
                //htReport.Save($@"\\192.168.1.200\form\{kilometer.Number}_{kilometer.Track_id}.html");
                var svg = htReport.Element("html").Element("body").Element("div").Element("div").Element("svg");
                var svgDoc = SvgDocument.FromSvg<SvgDocument>(svg.ToString());
                svgDoc.Width = 820*3;
                svgDoc.Height = (svgLength + 105)*3;

                if (autoprint)
                {

                    PrintDocument pd = new PrintDocument();
                    //pd.PrinterSettings.PrinterName = "EPSON5EEE22";
                    Console.WriteLine(pd.PrinterSettings.PrinterName);

                    pd.PrintPage += (sender, args) =>
                    {
                        var i = svgDoc.Draw();
                        //i.Save($@"g:\form\{kilometer.Number}_{kilometer.Track_id}.png");
                        pd.DefaultPageSettings.Margins = new Margins(0, 0, 0, 0);
                        pd.OriginAtMargins = false;
                        pd.DefaultPageSettings.Landscape = true;
                        Point p = new Point(0, 0);
                        args.Graphics.DrawImage(i, 0, 0, i.Width / 3, i.Height / 3 - 15);
                    };
                    pd.Print();

                }
                
                

            }
            catch(Exception e)
            {
                System.Console.WriteLine("file error: " + e.Message);
            }
            finally
            {
                // System.Diagnostics.Process.Start(Path.GetTempPath() + "/report.html");
            }
        }

        private string GetXByDigName(DigressionName digName)
        {
            float move = 6.6f;
            switch (digName)
            {
                case DigressionName.LongWaveLeft:
                    return MMToPixelChartString(LevelPosition + move);
                case DigressionName.LongWaveRight:
                    return MMToPixelChartString(+move);
                case DigressionName.MiddleWaveLeft:
                    return MMToPixelChartString(+move);
                case DigressionName.MiddleWaveRight:
                    return MMToPixelChartString(+move);
                case DigressionName.ShortWaveLeft:
                    return MMToPixelChartString(+move);
                case DigressionName.ShortWaveRight:
                    return MMToPixelChartString(+move);
            }

            return "-100";
        }
        private void PrintPage(object o, PrintPageEventArgs e, Image img)
        {
            
            Point loc = new Point(100, 100);
            e.Graphics.DrawImage(img, loc);
        }
    }
    public class Picket
    {
        public List<int> usedTops = new List<int>();
        public int start { private get; set; }
        public int Number { get; set; }
        public bool IsFilled
        {
            
            get
            {
                int count = 0;
                foreach (var note in Notes)
                {
                    if (note.Note.Contains("Уст") || (note.NotMoving))
                        count += 2;
                    else
                        count++;
                }
                return count>9; 
            }
        }
        public void AddNote(AlertNote node)
        { 

        }

        public void WriteNotesToReport(Kilometer kilometer, List<int> speedmetres, XElement addParam, XElement digElemenets, XDocument xml, float prosRightPosition, float prosLeftPosition, float straighRighttPosition, float strightLeftPosition, float gaugePosition, float levelPosition, Direction travel_Direction, List<int> strights,List<int> fmeter, MainParameters mainParameters, ref int fourStepOgrCoun, ref int otherfourStepOgrCoun)
        {
            
            foreach (var note in Notes)
            {
                
                try
                {
                    int meter = note.Top.RoundTo10();
                    if (!((meter >= start.RoundTo10()) && (meter < Number * 100)))
                        meter = start+10;
                    if (meter <= start.RoundTo10()+10)
                        meter += 10;
                    
                    if (usedTops.Contains(meter))
                        meter = usedTops.GetNextTop(start, meter, Number);
                    if (note.NotMoving)
                    {
                        addParam.Add(new XElement("speedline",
                            new XAttribute("y1", -(meter + 10)),
                            new XAttribute("y2", -(meter)),
                            new XAttribute("y3", -(meter + 20)),
                            new XAttribute("points", $"0,-{ meter + 10} 125,-{ meter + 10} 125,-{note.Top} 730,-{note.Top}"),
                            new XAttribute("note1", $"{note.Note.Split(';')[0]}"),
                            new XAttribute("note2", note.Note.Split(';')[1])));
                        usedTops.Add(meter.RoundTo10() + 10);
                        usedTops.Add(meter.RoundTo10());
                        continue;
                    }
                    if (note.Note.Contains("Уст.ск:"))
                    {
                        speedmetres.Add(-meter);
                        addParam.Add(new XElement("speedline",
                            new XAttribute("y1", -(meter+10)),
                            new XAttribute("y2", -(meter)),
                            new XAttribute("y3", -(meter+20)),
                            new XAttribute("points", $"0,-{ meter+10} 125,-{ meter + 10} 125,-{note.Top} 730,-{note.Top}"),
                            new XAttribute("note1", $"{note.Top} {note.Note.Split(' ')[1]}"),
                            new XAttribute("note2", "       " + note.Note.Split(' ')[2])));
                        usedTops.Add(meter.RoundTo10()+10);
                        usedTops.Add(meter.RoundTo10());
                        continue;

                    }
                    if (note.Note.Contains("Р+"))
                    {
                        
                        digElemenets.Add(new XElement("m",
                                                     new XAttribute("top", -meter),
                                                     new XAttribute("x", 1),
                                                     new XAttribute("note", note.Top),
                                                     new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                                    ));
                        digElemenets.Add(new XElement("otst",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 20),
                                             new XAttribute("note", note.Note.Split(' ')[1].ToString()),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));

                        digElemenets.Add(new XElement("len",
                                         new XAttribute("top", -meter),
                                         new XAttribute("x", 92),
                                         new XAttribute("note", note.Note.Split(' ')[3]),
                                         new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                        ));

                        digElemenets.Add(new XElement("ogrsk",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 135),
                                             new XAttribute("note", note.Note.Split(' ')[5]),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        usedTops.Add(meter);
                        continue;
                    }
                    if (note.Note.Contains("Уск") || note.Note.Contains("Укл") || note.Note.Contains("?Уkл"))
                    {

                        digElemenets.Add(new XElement("m",
                                                     new XAttribute("top", -meter),
                                                     new XAttribute("x", 1),
                                                     new XAttribute("note", note.Top),
                                                     new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                                    ));
                        digElemenets.Add(new XElement("otst",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 20),
                                             new XAttribute("note", note.Note.Split(' ')[1].ToString()),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("otkl",
                                            new XAttribute("top", -meter),
                                            new XAttribute("x", 63),
                                            new XAttribute("note", note.Note.Split(' ')[2].ToString()),
                                            new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")));


                       digElemenets.Add(new XElement("len",
                                         new XAttribute("top", -meter),
                                         new XAttribute("x", 92),
                                         new XAttribute("note", note.Note.Split(' ')[3]),
                                         new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                        ));

                        digElemenets.Add(new XElement("ogrsk",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 135),
                                             new XAttribute("note", note.Note.Split(' ')[5]),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        usedTops.Add(meter);
                        continue;
                    }


                    if (IsFilled)
                    {
                        meter = start;
                        if (usedTops.Contains(meter))
                            meter = usedTops.GetNextTopFromBottom(start, meter);
                        
                    }
                    usedTops.Add(meter);
                    var axisinv = xml.Root.Attribute("axisinv").Value.ToString();
                    var noteTypes = note.Note.Split(' ');

                    if (noteTypes.Length > 3)
                    {
                     
                        string stepen = note.Note.Split(' ')[2];

                        string noteType = note.Note.Split(' ')[1];
                        int.Parse(noteTypes[0]);
                        bool isMarkNote = true;
                        float markPosition = 0;
                        switch (noteType)
                        {

                            case "Пр.п":
                                markPosition = prosRightPosition;
                                break;
                            case "Пр.л":
                                markPosition = prosLeftPosition;
                                break;
                            case "Р":
                                markPosition = strightLeftPosition;
                                break;
                            case "У":
                            case "П":
                                markPosition = levelPosition;
                                break;
                            case "Уш":
                            case "Суж":
                                markPosition = gaugePosition;

                                break;
                            default:
                                isMarkNote = false;
                                break;
                        }

                        if (isMarkNote)
                        {

                            int defCoord = int.Parse(noteTypes[0]);
                            int length = (int.Parse(noteTypes[4]) / 2);
                            int strightStart = defCoord + length;
                            float prevPosition = markPosition;
                            int index;

                            if (markPosition == strightLeftPosition)
                            {

                                for (index = defCoord - length; index != defCoord + length; index++)
                                {

                                    if ((markPosition == strightLeftPosition) || (markPosition == straighRighttPosition))
                                    {
                                        //List<TrackObject> localStrights = (from stright in strights where Math.Abs(stright.Meter - index) < 4 select stright).ToList();
                                        prevPosition = markPosition;
                                        var mindex = fmeter.IndexOf(index);
                                        markPosition = strights[mindex > -1 ? mindex : mindex+1]<0 ? straighRighttPosition : strightLeftPosition;
                                        
                                        {
                                            digElemenets.Add(new XElement("line",
                                                new XAttribute("y1", -strightStart),
                                                new XAttribute("y2", -index),
                                                new XAttribute("x", mainParameters.MMToPixelChartString(markPosition)),
                                                new XAttribute("w",
                                                    mainParameters.MMToPixelChartWidthString(noteTypes[2].Equals("4") ? 4 :
                                                        noteTypes[2].Equals("3") ? 2 : 1))

                                            ));
                                        }
                                    }
                                }
                            }
                            else
                            {

                                digElemenets.Add(new XElement("line",
                                    new XAttribute("y1", -(defCoord-length)),
                                    new XAttribute("y2", -(defCoord+length)),
                                    new XAttribute("x", mainParameters.MMToPixelChartString(markPosition)),
                                    new XAttribute("w",
                                        mainParameters.MMToPixelChartWidthString(noteTypes[2].Equals("4") ? 4 :
                                            noteTypes[2].Equals("3") ? 2 : 1))

                            ));
                            }
                        }
                    }
                   
                    if (!note.Note.Contains("R"))
                    {
                        
                        
                        string noteType = note.Note.Split(' ')[1];
                        







                        string stepen = note.Note.Split(' ')[2];
                        int otkl = Convert.ToInt32(note.Note.Split(' ')[3]);
                        int dlina = Convert.ToInt32(note.Note.Split(' ')[4]);
                        //meter = meter + dlina / 2 ;
                        string ogrSk = "";
                        if ((note.Note.Split(' ')[5] != "") && (note.Note.Split(' ')[5] != "рн"))
                        {
                            ogrSk = note.Note.Split(' ')[5] + "/" + note.Note.Split(' ')[5].Split('/')[1];
                            if (stepen == "4")
                            {
                                fourStepOgrCoun = fourStepOgrCoun + 1;
                            }
                            if (stepen != "4")
                            {
                                otherfourStepOgrCoun = otherfourStepOgrCoun + 1;
                            }
                        }

                        
                        int count = 1;
                        switch (noteType)
                        {
                            case "Пр.п":
                            case "Пр.л":
                                count = -1;
                                break;
                            case "Суж":
                                count = dlina / 4;
                                count += dlina % 4 > 0 ? 1 : 0;
                                break;
                            case "Уш":
                                count = dlina / 4;
                                count += dlina % 4 > 0 ? 1 : 0;
                                break;
                            case "У":
                                count = dlina / 10;
                                count += dlina % 10 > 0 ? 1 : 0;
                                break;
                            case "П":
                                count = -1;
                                break;
                            case "Р":
                                count = -1;
                                break;
                        }
                        
                        digElemenets.Add(new XElement("m",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 1),
                                             new XAttribute("note", note.Top),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("otst",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 20),
                                             new XAttribute("note", noteType),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("step",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 50),
                                             new XAttribute("note", stepen),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("otkl",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 63),
                                             new XAttribute("note", otkl),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("len",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 92),
                                             new XAttribute("note", dlina),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("count",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 112),
                                             new XAttribute("note", count == -1 ? "" : count.ToString()),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                        digElemenets.Add(new XElement("ogrsk",
                                             new XAttribute("top", -meter),
                                             new XAttribute("x", 135),
                                             new XAttribute("note", ogrSk),
                                             new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                            ));
                    }
                    if (note.Note.Contains("R"))
                    {
                        
                        digElemenets.Add(new XElement("rect",

                                    new XAttribute("top", -meter - 9),
                                    new XAttribute("x", 0)
                                ));
                        digElemenets.Add(new XElement("R",
                                         new XAttribute("top", -meter),
                                         new XAttribute("x", 1),
                                         new XAttribute("note", note.Note),
                                         new XAttribute("fw", note.FontStyle == 0 ? "normal" : "bold")
                        ));

                    }
                }
                catch
                {
                    continue;
                }
            }
        }

        public List<AlertNote> Notes { get; set; } = new List<AlertNote>();

    }
    
}
