﻿using ALARm.Core.AdditionalParameteres;
using ALARm.Core.Report;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml.Linq;


namespace ALARm.Core
{

    public class Kilometer
    {
        public List<float> prosLeft = new List<float>();
        public List<float> prosRight = new List<float>();
        public List<float> fsh0 = new List<float>();
        public List<float> fsh = new List<float>();
        public List<float> fsr_rh1 = new List<float>();
        public List<float> frih1 = new List<float>();
        public List<float> frih10 = new List<float>();
        public List<float> fsr_rh2 = new List<float>();
        public List<float> frih2 = new List<float>();
        public List<float> frih20 = new List<float>();
        public List<float> fsr_urb = new List<float>();
        public List<float> furb = new List<float>();
        public List<float> furb0 = new List<float>();
        public List<AlertNote> LevelNotes = new List<AlertNote>();
        public List<AlertNote> StrigthLeftNotes = new List<AlertNote>();
        public List<AlertNote> StrigthRightNotes = new List<AlertNote>();
        public List<AlertNote> GaugeNotes = new List<AlertNote>();
        public List<AlertNote> DrawdownLeftNotes = new List<AlertNote>();
        public List<AlertNote> DrawdownRightNotes = new List<AlertNote>();

        public int Meter = 0;
        public int Correction = 0;
        public List<float> piketSpeeds;
        /// <summary>
        /// установленные скорости
        /// </summary>
        public List<Speed> Speeds;
        /// <summary>
        /// искусственные сооружения
        /// </summary>
        public List<ArtificialConstruction> Artificials;
        private Fragment fragment;
        /// <summary>
        /// административное деление
        /// </summary>
        public List<PdbSection> PdbSection;
        /// <summary>
        /// тип шпал
        /// </summary>
        public List<CrossTie> CrossTies;
        /// <summary>
        /// стрелочные переводы
        /// </summary>
        public List<Switch> Switches { get; set; }
        public List<CheckSection> CheckSections { get; set; }
        public List<Deep> Depths { get; set; }
        public List<StraighteningThread> StraighteningThreads { get; set; }
        public List<ProfileObject> IsoJoints { get; set; }
        public List<LongRails> LongRailses { get; set; }
        public List<Curve> Curves { get; set; }
        public int Id
        {
            get; set;
        }

        public int Number { get; set; }
        public int Start_m { get; set; } = 0;
        public int Final_m { get; set; } = 1000;
        public long Trip_id { get; set; }
        public long Direction_id { get; set; }
        public string Direction_name { get; set; }
        public string Direction_code { get; set; }
        public int Length { get; set; }
        public int GetLength() {
            return Math.Abs(Start_m - Final_m);
        }
        public int Track_id { get; set; }
        public string Track_name { get; set; }
        public DateTime Passage_time { get; set; }
        public string SignalGauge { get; set; } = "";
        public string Kupe { get; set; } = "";
        public string Koridor { get; set; } = "";
        public string PasportLevel { get; set; } = "";
        public string SignalLevel { get; set; } = "";
        public float StrightKoef = 3.5f;
        public float GaugeKoef = 2;
        public float WearKoef = 4;
        public float DegKoef = 1000;

        public List<double> Level = new List<double>();
        public List<double> LevelAvg = new List<double>();
        public List<double> Gauge = new List<double>();
        public List<double> _Kupe = new List<double>();
        public List<double> _Koridor = new List<double>();
        public List<double> StrightLeft = new List<double>();

        public void Clear(Kilometer kilometer = null, int clearCount = -1)
        {
            if (kilometer != null)
                for (int i = 0; i < Speed.Count; i++)
                {
                    kilometer.Speed.Add(Speed[i]);
                    kilometer.DrawdownRight.Add(DrawdownRight[i]);
                    kilometer.DrawdownLeft.Add(DrawdownLeft[i]);
                    kilometer.Gauge.Add(Gauge[i]);
                    kilometer.StrightRight.Add(StrightRight[i]);
                    kilometer.StrightLeft.Add(StrightLeft[i]);
                    kilometer.Level.Add(Level[i]);
                    kilometer.LevelAvg.Add(LevelAvg[i]);
                    kilometer.StrightAvg.Add(StrightAvg[i]);
                    kilometer.Level0.Add(Level0[i]);
                    kilometer.Meters.Add(Meters[i]);
                    kilometer.RealKm.Add(RealKm[i]);
                    kilometer.Latitude.Add(Latitude[i]);
                    kilometer.Longitude.Add(Longitude[i]);
                    kilometer.XCamLeft.Add(XCamLeft[i]);
                    kilometer.XCamRight.Add(XCamRight[i]);
                    kilometer.SwitchesReal.Add(SwitchesReal[i]);
                    kilometer.LevelCorrection.Add(Level[i]);
                    kilometer.GaugeCorrection.Add(GaugeCorrection[i]);
                    kilometer._Kupe.Add(_Kupe[i]);
                    kilometer._Koridor.Add(_Koridor[i]);
                    kilometer.GaugeCorrection.Add(GaugeCorrection[i]);
                    kilometer.Corrections.Add(Corrections[i]);


                    kilometer.SignalLevel += (-1 * Level[i]).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.ZeroLevel += (-1 * LevelAvg[i]).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.SignalStraightLeft += (-1 * StrightLeft[i] * kilometer.StrightKoef).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.SignalStraightRight += (-1 * StrightRight[i] * kilometer.StrightKoef).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.ZeroStraightLeft += (-1 * StrightAvg[i] * kilometer.StrightKoef).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.ZeroStraightRight += (-1 * StrightAvg[i] * kilometer.StrightKoef).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.SignalDrawdownLeft += (-1 * DrawdownLeft[i]).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.SignalDrawdownRight += (-1 * DrawdownRight[i]).ToString().Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.SignalGauge += ((Gauge[i] - 1520) * kilometer.GaugeKoef).ToString("0.00").Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.Kupe += ((Gauge[i] - 1520) * kilometer.GaugeKoef).ToString("0.00").Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.Koridor += ((Gauge[i] - 1520) * kilometer.GaugeKoef).ToString("0.00").Replace(",", ".") + "," + kilometer.Meter.ToString() + " ";
                    kilometer.Meter++;
                }
            if (clearCount == -1)
            {
                Speed.Clear();
                DrawdownRight.Clear();
                DrawdownLeft.Clear();
                Gauge.Clear();
                StrightRight.Clear();
                StrightLeft.Clear();
                Level.Clear();
                LevelAvg.Clear();
                StrightAvg.Clear();
                Level0.Clear();
                Meters.Clear();
                RealKm.Clear();
                Latitude.Clear();
                Longitude.Clear();
                XCamLeft.Clear();
                XCamRight.Clear();
                SwitchesReal.Clear();
                LevelCorrection.Clear();
                GaugeCorrection.Clear();
                Corrections.Clear();
                SignalLevel = " ";
                ZeroLevel = " ";
                SignalStraightLeft = " ";
                SignalStraightRight = " ";
                ZeroStraightLeft = " ";
                ZeroStraightRight = " ";
                SignalDrawdownLeft = " ";
                SignalDrawdownRight = " ";
                SignalGauge = " ";
                Meter = 0;
            }
            else
            {
                              
                int clearIndex = Speed.Count - clearCount;
                SignalLevel = SignalLevel.CutFromIndex(" ", clearIndex);
                ZeroLevel = ZeroLevel.CutFromIndex(" ", clearIndex); 
                SignalStraightLeft = SignalStraightLeft.CutFromIndex(" ", clearIndex);
                SignalStraightRight = SignalStraightRight.CutFromIndex(" ", clearIndex);
                ZeroStraightLeft = ZeroStraightLeft.CutFromIndex(" ", clearIndex);
                ZeroStraightRight = ZeroStraightRight.CutFromIndex(" ", clearIndex);
                SignalDrawdownLeft = SignalDrawdownLeft.CutFromIndex(" ", clearIndex);
                SignalDrawdownRight = SignalDrawdownRight.CutFromIndex(" ", clearIndex);
                SignalGauge = SignalGauge.CutFromIndex(" ", clearIndex);
                Kupe = Kupe.CutFromIndex(" ", clearIndex);
                Koridor = Koridor.CutFromIndex(" ", clearIndex);
                Speed.RemoveRange(clearIndex, clearCount);
                DrawdownRight.RemoveRange(clearIndex, clearCount);
                DrawdownLeft.RemoveRange(clearIndex, clearCount);
                Gauge.RemoveRange(clearIndex, clearCount);
                StrightRight.RemoveRange(clearIndex, clearCount);
                StrightLeft.RemoveRange(clearIndex, clearCount);
                Level.RemoveRange(clearIndex, clearCount);
                LevelAvg.RemoveRange(clearIndex, clearCount);
                StrightAvg.RemoveRange(clearIndex, clearCount);
                Level0.RemoveRange(clearIndex, clearCount);
                Meters.RemoveRange(clearIndex, clearCount);
                RealKm.RemoveRange(clearIndex, clearCount);
                Latitude.RemoveRange(clearIndex, clearCount);
                Longitude.RemoveRange(clearIndex, clearCount);
                XCamLeft.RemoveRange(clearIndex, clearCount);
                XCamRight.RemoveRange(clearIndex, clearCount);
                SwitchesReal.RemoveRange(clearIndex, clearCount);
                LevelCorrection.RemoveRange(clearIndex, clearCount);
                GaugeCorrection.RemoveRange(clearIndex, clearCount);
                Corrections.RemoveRange(clearIndex, clearCount);



            }
        }

        public List<double> StrightRight = new List<double>();
        public List<double> StrightAvg = new List<double>();
        public List<double> Level0 = new List<double>();
        public List<double> GaugeCorrection = new List<double>();
        public List<double> LevelCorrection = new List<double>();
        public List<double> SideWearLeft_ = new List<double>();
        public List<double> SideWearRight_ = new List<double>();
        public List<double> RealKm = new List<double>();
        public List<double> Latitude = new List<double>();
        public List<double> Longitude = new List<double>();
        public List<int> Speed = new List<int>();
        public List<int> Corrections = new List<int>();
        public List<double> DrawdownLeft = new List<double>();
        public List<double> DrawdownRight = new List<double>();
        public List<double> XCamLeft = new List<double>();
        public List<double> XCamRight = new List<double>();
        public List<double> SwitchesReal = new List<double>();
        public List<int> Meters = new List<int>();
        public List<int> _Meters = new List<int>();

        private List<AlertNote> Notes { get; set; }
        public List<DigressionMark> Digressions { get; set; }
        public List<Gap> Gaps { get; set; }
        public List<Heat> Heats { get; set; }
        private bool ShifrovkaGenerated { get; set; } = false;
        public bool IsPrinted { get; set; } = false;
        public void AddData(OutData outdata, int direction, int meter)
        {

            Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
            Speed.Add(outdata.speed);
            DrawdownRight.Add(outdata.drawdown_right);
            DrawdownLeft.Add(outdata.drawdown_left);
            Gauge.Add(outdata.gauge);
            StrightRight.Add(outdata.stright_right);
            StrightLeft.Add(outdata.stright_left);
            Level.Add(outdata.level);
            LevelAvg.Add(outdata.level_avg);
            StrightAvg.Add(outdata.stright_avg);
            Level0.Add(outdata.level_zero);
            Meters.Add(meter);
            _Meters.Add(outdata._meters);
            RealKm.Add(outdata.km);
            Latitude.Add(outdata.latitude);
            Longitude.Add(outdata.longitude);
            XCamLeft.Add(outdata.x101_kupe);
            XCamRight.Add(outdata.x102_koridor);
            SwitchesReal.Add(0);
            LevelCorrection.Add(outdata.level_correction);
            GaugeCorrection.Add(outdata.gauge_correction);
            Corrections.Add(outdata.correction);

            _Kupe.Add(outdata.y101_kupe);
            _Koridor.Add(outdata.y102_koridor);

            SignalLevel += $"{(-1 * outdata.level).ToString("0.00")},{Meter} ";
            ZeroLevel += $"{(-1 * outdata.level_avg).ToString("0.00")},{Meter} ";
            SignalStraightLeft += $"{(-1 * outdata.stright_left * StrightKoef).ToString("0.00")},{Meter} ";
            SignalStraightRight += $"{(-1 * outdata.stright_right * StrightKoef).ToString("0.00")},{Meter} ";
            ZeroStraightLeft += $"{(-1 * outdata.stright_avg * StrightKoef).ToString("0.00")},{Meter} ";
            ZeroStraightRight += $"{(-1 * outdata.stright_avg * StrightKoef).ToString("0.00")},{Meter} ";
            SignalDrawdownLeft += $"{(-1 * outdata.drawdown_left).ToString("0.00")},{Meter} ";
            SignalDrawdownRight += $"{(-1 * outdata.drawdown_right).ToString("0.00")},{Meter} ";
            SignalGauge += $"{((outdata.gauge - 1520) * GaugeKoef).ToString("0.00")},{Meter} ";
            Kupe += $"{((outdata.x101_kupe - 86) * -3).ToString("0.00")},{Meter} ";
            Koridor += $"{((outdata.x102_koridor - 100) * -3).ToString("0.00")}, {Meter} ";
            Meter++;
        }
        public bool WriteData(Trips trip, bool autoprint)
        {
            if (ShifrovkaGenerated)
                return false;

            CultureInfo customCulture = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentCulture = customCulture;
            var _ = "\t";
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            var fileName = $@"G:\work_shifrovka\km_{Number}_{Track_id}.svgpdat";

            try
            {
                using (StreamWriter writetext = new StreamWriter(fileName, false, Encoding.GetEncoding(1251)))


                {
                    writetext.WriteLine($@"{trip.Id}");
                    writetext.WriteLine($@"{trip.Direction_Name}");
                    writetext.WriteLine(trip.Direction_id);
                    writetext.WriteLine(trip.Chief);
                    writetext.WriteLine(Number);
                    writetext.WriteLine(Track_name);
                    writetext.WriteLine(Track_id);
                    writetext.WriteLine(trip.Travel_Direction == Direction.Direct ? "Прямой" : "Обратный");
                    writetext.WriteLine(trip.Trip_date.ToString("dd.MM.yyyy  HH:mm"));
                    writetext.WriteLine(trip.Car);
                    writetext.WriteLine();
                    int j = 0;

                    for (int i = trip.Travel_Direction == Direction.Direct ? Start_m : Final_m; i != (trip.Travel_Direction == Direction.Direct ? Final_m : Start_m); i = i + (int)trip.Travel_Direction)
                    {
                        //                      0       1            2           3           4                                     5                                    6                             7                                   8                                    9                             10                                 11                               12                             13                                 14                               15                                16                  17                                      18
                        writetext.WriteLine($@"{j}{_}{Speed[j]}{_}{i / 100 + 1}{_}{i % 100}{_}{DrawdownRight[j].ToString("0.00")}{_}{DrawdownLeft[j].ToString("0.00")}{_}{Gauge[j].ToString("0.00")}{_}{StrightRight[j].ToString("0.00")}{_}{StrightLeft[j].ToString("0.00")}{_}{Level[j].ToString("0.00")}{_}{StrightAvg[j].ToString("0.00")}{_}{LevelAvg[j].ToString("0.00")}{_}{Level0[j].ToString("0.00")}{_}{StrightAvg[j].ToString("0.00")}{_}{Latitude[j].ToString("0.00")}{_}{Longitude[j].ToString("0.00")}{_}{SwitchesReal[j]}{_}{LevelCorrection[j].ToString("0.00")}{_}{GaugeCorrection[j].ToString("0.00")}{_}{SideWearRight_[j].ToString("0.00")}{_}{SideWearLeft_[j].ToString("0.00")}{_}{Corrections[j]}");
                        j++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Ошибка при формировании уоркшифровки: " + e.Message);
            }
            ShifrovkaGenerated = true;
            
            var process = System.Diagnostics.Process.Start(@"G:\sntfi\ALARm5\ALARmProcees\Win32\Debug\ALARmProcess.exe", $"{fileName} {Correction}");
            process.WaitForExit();
            
            return ShifrovkaGenerated;
        }
        public CrossRailProfile CrossRailProfile { get; set; }
        public void CalcRailProfileLines(Trips trip)
        {
            if (CrossRailProfile == null)
                return;
            var sideWearLeft = new StringBuilder();
            var sideWearRight = new StringBuilder();
            var vertWearLeft = new StringBuilder();
            var vertWearRight = new StringBuilder();
            var givenWearLeft = new StringBuilder();
            var givenWearRight = new StringBuilder();
            var treadTiltLeft = new StringBuilder();
            var treadTiltRight = new StringBuilder();
            var downHillLeft = new StringBuilder();
            var downHillRight = new StringBuilder();
            var headWear45Left = new StringBuilder();
            var headWear45Right = new StringBuilder();

            foreach (var meter in CrossRailProfile.Meters.Where(meter => meter % 1 == 0).ToList())
            {

                int index = CrossRailProfile.Meters.IndexOf(meter);
                var cmeter = trip.Travel_Direction == Direction.Reverse ? meter : Length - meter;
                sideWearLeft.Append((CrossRailProfile.SideWearLeft[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                sideWearRight.Append((CrossRailProfile.SideWearRight[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                vertWearLeft.Append((CrossRailProfile.VertIznosL[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                vertWearRight.Append((CrossRailProfile.VertIznosR[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                givenWearLeft.Append((CrossRailProfile.ReducedWearLeft[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                givenWearRight.Append((CrossRailProfile.ReducedWearRight[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                treadTiltLeft.Append((CrossRailProfile.TreadTiltLeft[index] * DegKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                treadTiltRight.Append((CrossRailProfile.TreadTiltRight[index] * DegKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                downHillLeft.Append((CrossRailProfile.DownhillLeft[index] * DegKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                downHillRight.Append((CrossRailProfile.DownhillRight[index] * DegKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                headWear45Left.Append((CrossRailProfile.HeadWearLeft[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");
                headWear45Right.Append((CrossRailProfile.HeadWearRight[index] * WearKoef).ToString().Replace(",", ".") + "," + cmeter.ToString().Replace(",", ".") + " ");

            }
            SideWearLeft = sideWearLeft.ToString();
            SideWearRight = sideWearRight.ToString();
            VertWearLeft = vertWearLeft.ToString();
            VertWearRight = vertWearRight.ToString();
            GivenWearLeft = givenWearLeft.ToString();
            GivenWearRight = givenWearRight.ToString();
            TreadTiltLeft = treadTiltLeft.ToString();
            TreadTiltRight = treadTiltRight.ToString();
            DownHillLeft = downHillLeft.ToString();
            DownHillRight = downHillRight.ToString();
            HeadWear45Left = headWear45Left.ToString();
            HeadWear45Right = headWear45Right.ToString();
        }


        public void LoadPasport(IMainTrackStructureRepository mainTrackStructureRepository)
        {
            Speeds = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoSpeed, Direction_name, Track_name) as List<Speed>;
            Artificials = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoArtificialConstruction, Direction_name, Track_name) as List<ArtificialConstruction>;
            PdbSection = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoPdbSection, Direction_name, Track_name) as List<PdbSection>;
            CrossTies = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoCrossTie, Direction_name, Track_name) as List<CrossTie>;
            Switches = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoSwitch, Direction_name, Track_name) as List<Switch>;
            StraighteningThreads = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoStraighteningThread, Direction_name, Track_name) as List<StraighteningThread>;
            LongRailses = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoLongRails, Direction_name, Track_name) as List<LongRails>;
            CheckSections = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoCheckSection, Direction_name, Track_name) as List<CheckSection>;
            Depths = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoDeep, Direction_name, Track_name) as List<Deep>;
            Curves = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoCurve, Direction_name, Track_name) as List<Curve>;
            StraighteningThreads = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoStraighteningThread, Direction_name, Track_name) as List<StraighteningThread>;
            IsoJoints = mainTrackStructureRepository.GetMtoObjectsByCoord(Passage_time, Number, MainTrackStructureConst.MtoProfileObject, Direction_name, Track_name) as List<ProfileObject>;
        }

        public void LoadTrackPasport(IMainTrackStructureRepository mainTrackStructureRepository, DateTime trip_date)
        {
            Speeds = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoSpeed, Track_id) as List<Speed>;
            Artificials = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoArtificialConstruction, Track_id) as List<ArtificialConstruction>;
            PdbSection = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoPdbSection, Track_id) as List<PdbSection>;
            CrossTies = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoCrossTie, Track_id) as List<CrossTie>;
            if (CrossTies.Count == 0)
            {
                CrossTies.Add(new CrossTie { Crosstie_type_id = (int)CrosTieType.Woody, Start_Km = Number, Start_M = 1, Final_Km = Number, Final_M = Final_m });
            }
            Switches = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoSwitch, Track_id) as List<Switch>;
            StraighteningThreads = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoStraighteningThread, Track_id) as List<StraighteningThread>;
            LongRailses = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoLongRails, Track_id) as List<LongRails>;
            CheckSections = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoCheckSection, Track_id) as List<CheckSection>;
            Depths = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoDeep, Track_id) as List<Deep>;
            Curves = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoCurve, Track_id) as List<Curve>;

            IsoJoints = mainTrackStructureRepository.GetMtoObjectsByCoord(trip_date, Number, MainTrackStructureConst.MtoProfileObject, Track_id) as List<ProfileObject>;
        }
        public void LoadFromXml(Trips trip, IMainTrackStructureRepository mainTrackStructureRepository)
        {
            var xml = XDocument.Load(@"G:\work_shifrovka\" + Number + ".xml");
            prosLeft = xml.Root.Element("prosleft").Elements("pr").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            prosRight = xml.Root.Element("prosright").Elements("pr").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            fsh0 = xml.Root.Element("fsh0").Elements("sh0").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            fsh = xml.Root.Element("fsh").Elements("sh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            fsr_rh1 = xml.Root.Element("fsr_rh1").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            frih1 = xml.Root.Element("frih1").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            frih10 = xml.Root.Element("frih10").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            fsr_rh2 = xml.Root.Element("fsr_rh2").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            frih2 = xml.Root.Element("frih2").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            frih20 = xml.Root.Element("frih20").Elements("rh").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            fsr_urb = xml.Root.Element("fsr_urb").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            furb = xml.Root.Element("furb").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            furb0 = xml.Root.Element("furb0").Elements("urb").Select(x => (float)Convert.ToDouble(x.Value)).ToList();
            Notes = (from note in xml.Root.Element("notes").Elements("note")
                     select new AlertNote()
                     {
                         Note = (string)note.Attribute("note"),
                         Top = (int)note.Attribute("top"),
                         Left = (int)note.Attribute("left"),
                         FontStyle = (int)note.Attribute("fstyle")
                     }).ToList();
            piketSpeeds = xml.Root.Elements("piketspeed").Select(x => (float)Convert.ToDouble(x.Value)).ToList();



            //trip.Travel_Direction = (Direction)Convert.ToInt32(xml.Root.Element("axisinv").Value);


            Speeds = mainTrackStructureRepository.GetMtoObjectsByCoord(trip.Trip_date, Number,
                MainTrackStructureConst.MtoSpeed, trip.Direction_Name, "1") as List<Speed>;
            fragment = mainTrackStructureRepository.GetMtoObjectsByCoord(trip.Trip_date, Number,
                MainTrackStructureConst.Fragments, trip.Direction_Name, "1") as Fragment;
            PdbSection = mainTrackStructureRepository.GetMtoObjectsByCoord(trip.Trip_date, Number,
                MainTrackStructureConst.MtoPdbSection, trip.Direction_Name, "1") as List<PdbSection>;
            var signalGauge = new StringBuilder();
            var pasportGauge = new StringBuilder();
            var zeroLevel = new StringBuilder();
            var pasportLevel = new StringBuilder();
            var signalLevel = new StringBuilder();
            var signalDrawdownLeft = new StringBuilder();
            var signalDrawdownRight = new StringBuilder();
            var zeroStraightRight = new StringBuilder();
            var pasportStraightRight = new StringBuilder();
            var signalStraightRight = new StringBuilder();
            var zeroStraightLeft = new StringBuilder();
            var pasportStraightLeft = new StringBuilder();
            var signalStraightLeft = new StringBuilder();

            for (int index = 0; index < prosRight.Count; index++)
            {
                int metre = trip.Travel_Direction == Direction.Direct ? Length - index : index;

                signalGauge.Append(((fsh[index] - fsh0[index]) * GaugeKoef).ToString().Replace(",", ".") + "," + metre + " ");
                pasportGauge.Append(((fsh0[index] - 1520) * GaugeKoef).ToString().Replace(",", ".") + "," + metre + " ");

                zeroLevel.Append((-1 * fsr_urb[index]).ToString().Replace(",", ".") + "," + metre + " ");
                pasportLevel.Append((-1 * furb0[index]).ToString().Replace(",", ".") + "," + metre + " ");
                signalLevel.Append((-1 * furb[index]).ToString().Replace(",", ".") + "," + metre + " ");

                signalDrawdownLeft.Append((prosLeft[index]).ToString().Replace(",", ".") + "," + metre + " ");
                signalDrawdownRight.Append((prosRight[index]).ToString().Replace(",", ".") + "," + metre + " ");

                zeroStraightRight.Append((-1 * fsr_rh2[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");
                pasportStraightRight.Append((-1 * frih20[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");
                signalStraightRight.Append((-1 * frih2[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");

                zeroStraightLeft.Append((-1 * fsr_rh1[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");
                pasportStraightLeft.Append((-1 * frih10[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");
                signalStraightLeft.Append((-1 * frih1[index] * StrightKoef).ToString().Replace(",", ".") + "," + metre + " ");
            }

            SignalGauge = signalGauge.ToString();
            PasportGauge = pasportGauge.ToString();
            ZeroLevel = zeroLevel.ToString();
            PasportLevel = PasportLevel.ToString();
            SignalLevel = signalLevel.ToString();
            SignalDrawdownRight = signalDrawdownRight.ToString();
            SignalDrawdownLeft = signalDrawdownLeft.ToString();
            ZeroStraightLeft = zeroStraightLeft.ToString();
            PasportStraightLeft = pasportStraightLeft.ToString();
            SignalStraightLeft = signalStraightLeft.ToString();
            ZeroStraightRight = zeroStraightRight.ToString();
            PasportStraightRight = pasportStraightRight.ToString();
            SignalStraightRight = signalStraightRight.ToString();


            char separator = CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalSeparator[0];
            List<TrackObject> strights = (from stright in xml.Root.Element("straightening").Elements("stright")
                                          select new TrackObject()
                                          {
                                              Meter = double.Parse(((string)stright.Attribute("meter")).Replace(',', separator)) * 100,
                                              Value = (int)stright.Attribute("type")
                                          }).ToList();
            Digressions = new List<DigressionMark>();
            foreach (var note in Notes)
            {
                if (note.Note.Contains("Уст.ск:"))
                {
                    continue;
                }
                var noteTypes = note.Note.Split(' ');
                if (noteTypes.Length > 3)
                {
                    string noteType = note.Note.Split(' ')[1];
                    int.Parse(noteTypes[0]);
                    bool isMarkNote = true;
                    var digression = new DigressionMark();
                    //digression.DigNameToDigression(noteType);
                    switch (noteType)
                    {
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.DrawdownRight)):
                            digression.Digression = DigressionName.DrawdownRight;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.DrawdownLeft)):
                            digression.Digression = DigressionName.DrawdownLeft;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.Level)):
                            digression.Digression = DigressionName.Level;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.Strightening)):
                            digression.Digression = DigressionName.Strightening;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.Sag)):
                            digression.Digression = DigressionName.Sag;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.Broadening)):
                            digression.Digression = DigressionName.Broadening;
                            break;
                        case string digname when digname.Equals(digression.GetDigName(DigressionName.Constriction)):
                            digression.Digression = DigressionName.Constriction;
                            break;
                        default:
                            isMarkNote = false;
                            break;
                    }
                    if (isMarkNote)
                    {
                        int strightStart = int.Parse(noteTypes[0]);
                        digression.Meter = int.Parse(noteTypes[0]);
                        //digression.Meter = trip.Travel_Direction == Direction.Direct ? digression.Meter : Length - digression.Meter;
                        if (digression.Digression == DigressionName.Strightening)
                        {
                            List<TrackObject> localStrights = (from stright in strights
                                                               where Math.Abs(stright.Meter * 100 - digression.Meter) < 4
                                                               select stright).ToList();
                            digression.Digression = localStrights.Count > 0 && localStrights[0].Value == -1
                                ? DigressionName.StrighteningRight
                                : DigressionName.StrighteningLeft;
                        }
                        digression.Degree = int.Parse(noteTypes[2]);
                        digression.Value = float.Parse(noteTypes[3]);
                        digression.Length = int.Parse(noteTypes[4]);


                        Digressions.Add(digression);
                    }
                }
            }
            Digressions = Digressions.OrderBy(digression => digression.Meter).ToList();
        }
        public string File_path { get; set; }
        public int Next_Km { get; set; }
        public int Point { get; set; } = -1;
        public string ZeroLevel { get; set; } = "";
        public string ZeroStraightRight { get; set; } = "";
        public string PasportStraightRight { get; set; } = "";
        public string SignalStraightRight { get; set; } = "";
        public string ZeroStraightLeft { get; set; } = "";
        public string PasportStraightLeft { get; private set; } = "";
        public string SignalStraightLeft { get; set; } = "";
        public string PasportGauge { get; set; } = "";
        public string SignalDrawdownLeft { get; set; } = "";
        public string SignalDrawdownRight { get; set; } = "";
        public string SideWearLeft { get; set; } = "";
        public string VertWearLeft { get; set; } = "";
        public string VertWearRight { get; set; } = "";
        public string GivenWearLeft { get; private set; } = "";
        public string GivenWearRight { get; private set; } = "";
        public string TreadTiltLeft { get; private set; } = "";
        public string SideWearRight { get; set; } = "";
        public string TreadTiltRight { get; private set; } = "";
        //подкулонка
        public string DownHillLeft { get; set; } = "";
        public string DownHillRight { get; set; } = "";
        public string HeadWear45Left { get; set; } = "";
        public string HeadWear45Right { get; set; } = "";
        public int Start_Index { get; set; } = -1;
        public int Final_Index => Start_Index + GetLength();

        public override string ToString()
        {
            return $@"{Number} - {Start_m} - {Final_m}";
        }
        public string GetFill()
        {
            switch (Point)
            {
                case 10: return "#33FF3C";
                case 40: return "blue";
                case 150: return "yellow";
                case 500: return "red";
                default: return "black";
            }
        }
    }
    public static class MyList {

        public static string CutFromIndex(this string str, string value, int cutIndex)
        {
            if (String.IsNullOrEmpty(value))
                throw new ArgumentException("the string to find may not be empty", "value");
            var foundCount = 0;
            for (int index = 0; ; index += value.Length)
            {
                index = str.IndexOf(value, index);
                if (index == -1)
                    return str;
                foundCount++;
                if (foundCount == cutIndex)
                    return str.Remove(index, str.Length - index);
                
            }
        }
        

    }
}

