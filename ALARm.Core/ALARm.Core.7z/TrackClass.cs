﻿namespace ALARm.Core
{
    public class TrackClass : MainTrackObject
    {
        public int Class_Id { get; set; }
        public string Class_Type { get; set; }
    }
}