﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class MainTrackObject
    { 
        public Int64 Id { get; set; }
        public int Start_Km { get; set; }
        public int Start_M { get; set; }
        public int Final_Km { get; set; }
        public int Final_M { get; set; }
        private long DirectionId { get; set; }
        public long Period_Id { get; set; }
        public double RealStartCoordinate()
        {
            return Start_Km + Start_M / 10000.0;
        }
        public double RealFinalCoordinate()
        {
            return Final_Km + Final_M / 10000.0;
        }
    }
}
    
