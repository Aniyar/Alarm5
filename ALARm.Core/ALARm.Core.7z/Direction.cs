﻿namespace ALARm.Core
{
    public enum Direction { Reverse = -1, NotDefined = 0, Direct = 1 }

}