﻿namespace ALARm.Core
{
    public class Park : StationObject { }
}