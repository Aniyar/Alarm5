﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class Profmarks : MainTrackObject
    {
        public int Km { get; set; }
        public int Meter { get; set; }
        public double Profil { get; set; }
    }
}
