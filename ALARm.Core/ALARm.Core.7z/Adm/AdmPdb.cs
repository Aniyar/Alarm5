﻿namespace ALARm.Core
{
    public class AdmPdb : AdmUnit
    {
        public AdmPd Parent { get; set; }
        

    }
}