﻿namespace ALARm.Core
{
    public class AdmDirection : AdmUnit {
        private new string Chief_fullname { get; set; }
    }
}