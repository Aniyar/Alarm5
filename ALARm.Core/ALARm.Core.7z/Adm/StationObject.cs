﻿namespace ALARm.Core
{
    public class StationObject : AdmUnit {
        public int Type_id { get; set; }
        private new string Chief_fullname { get; set; }
        public string Object_type { get; set; }
        public int Length { get; set; }
        
    }
}