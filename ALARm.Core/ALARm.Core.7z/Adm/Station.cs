﻿namespace ALARm.Core
{
    public class Station : StationObject { }
}