﻿namespace ALARm.Core
{
    public class AdmDistance : AdmUnit
    {
        public AdmNod Parent { get; set; }
        

    }
}