﻿using System;

namespace ALARm.Core
{
    public class Class1
    {
    }
}
