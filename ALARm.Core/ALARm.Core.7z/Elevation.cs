﻿namespace ALARm.Core
{
    public class Elevation : MainTrackObject
    {
        public string Side { get; set; }
        public int Level_Id { get; set; }
    }
}