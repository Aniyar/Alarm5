﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class Waycat : MainTrackObject
    {
        public int Type_id { get; set; }
        public string Type { get; set; }
    }
}
