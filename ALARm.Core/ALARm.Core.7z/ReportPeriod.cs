﻿using System;
using System.Globalization;

namespace ALARm.Core
{
    public class ReportPeriod
    {
        public int Id { get; set; }
        public int PeriodYear { get; set;}
        public int PeriodMonth { get; set;}
        public string Period => CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(PeriodMonth) + ' ' + PeriodYear.ToString();
        public DateTime StartDate => new DateTime(PeriodYear, PeriodMonth, 1);
        public DateTime FinishDate => StartDate.AddMonths(1).AddDays(-1);
        public override string ToString()
        {
            return PeriodMonth + "-" + PeriodYear;
        }

    }
}