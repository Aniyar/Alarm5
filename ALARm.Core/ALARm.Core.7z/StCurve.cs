﻿namespace ALARm.Core
{
    public class StCurve : MainTrackObject
    {
        public float Radius { get; set; }
        public float Wear { get; set; }
        public int Width { get; set; }
        public int Transition_1 { get; set; }
        public int Transition_2 { get; set; }

    }
}
