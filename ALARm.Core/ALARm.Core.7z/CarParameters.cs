﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class CarParameters
    {
        public string ChiefName { get; set; }
        public CarPosition CurrentPosition { get; set; }
        public string CarNumber { get; set; }
    }
}
