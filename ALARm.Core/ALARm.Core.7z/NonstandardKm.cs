﻿namespace ALARm.Core
{
    public class NonstandardKm : MainTrackObject
    {
        public int Len { get; set; }
        public int Km { get; set; }
    }
}