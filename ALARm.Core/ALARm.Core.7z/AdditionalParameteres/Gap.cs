﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ALARm.Core.Report;

namespace ALARm.Core.AdditionalParameteres
{
    public class Gap : RdObject
    {
        public int Length { get; set; }
        public int Threat { get; set; }
        public int Direction { get; set; }
        public new int Km { get; set; }
        public new int Meter { get; set; }
        public int Picket { get; set; }
        public int Zazor { get; set; }
        public int Thread { get; set; }
        public int Start { get; set; }
        public string Name { get; set; }
        public int Code { get; set; }
        public int Put { get; set; }
        public int Pch { get; set; }
        public int PassSpeed { get; set; }
        public int FreightSpeed { get; set; }
        public int File_Id { get; set; }
        public int Step { get; set; }
        public int Frame_Number { get; set; }
        public Side Side { get; set; }
        public Digression GetDigressions()
        {
            Digression digression = new Digression();
            digression.FullSpeed = PassSpeed + "/" + FreightSpeed;
            digression.Meter = Meter;
            digression.Kmetr = Km;
            digression.Threat = (Threat)Thread;
            digression.Velich = Length;
            switch (Length)
            {
                case 0:
                    digression.AllowSpeed = "";
                    digression.DigName = DigressionName.FusingGap;
                    break;
                case int gap when gap > 24 && gap <= 26:
                    digression.AllowSpeed = (PassSpeed > 100 ? "100" : "-") + "/" + (FreightSpeed > 100 ? "100" : "-");
                    digression.DigName = digression.AllowSpeed.Equals("-/-") ? DigressionName.AnomalisticGap : DigressionName.Gap;
                    break;
                case int gap when gap > 26 && gap <= 30:
                    digression.AllowSpeed = (PassSpeed > 60 ? "60" : "-") + "/" + (FreightSpeed > 60 ? "60" : "-");
                    digression.DigName = digression.AllowSpeed.Equals("-/-") ? DigressionName.AnomalisticGap : DigressionName.Gap;
                    break;
                case int gap when gap > 30 && gap <= 35:
                    digression.AllowSpeed = (PassSpeed > 25 ? "25" : "-") + "/" + (FreightSpeed > 25 ? "25" : "-");
                    digression.DigName = digression.AllowSpeed.Equals("-/-") ? DigressionName.AnomalisticGap : DigressionName.Gap;
                    break;
                case int gap when gap > 35:
                    digression.AllowSpeed = "0/0";
                    digression.DigName = DigressionName.Gap;
                    break;
            }
            return digression;
        }
    }
    public class Heat : RdObject
    {
        public int Value { get; set; }
    }
}
