﻿namespace ALARm.Core
{
    /// <summary>
    /// Рихтовочная нить
    /// </summary>

    public class StraighteningThread : MainTrackObject {
        public int Side_Id { get; set; }
        public string Side { get; set; }
    }
}