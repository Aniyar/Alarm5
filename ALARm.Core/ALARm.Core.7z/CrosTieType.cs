﻿namespace ALARm.Core
{
    public enum CrosTieType { Before96 = 1, Before2005 =17, Concrete = 2, Woody = 3 }
}