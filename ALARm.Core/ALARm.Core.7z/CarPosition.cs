﻿namespace ALARm.Core
{
    public enum CarPosition { Base = 1, NotDefined = 0, Boiler = -1};
}