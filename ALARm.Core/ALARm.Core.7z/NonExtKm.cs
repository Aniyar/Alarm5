﻿namespace ALARm.Core
{
    public class NonExtKm : MainTrackObject
    {
        public int Km { get; set; }
    }
}
