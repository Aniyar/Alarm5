﻿namespace ALARm.Core
{
    public class CrossTie : MainTrackObject
    {
        public int Crosstie_type_id { get; set; }
        public string CrossTie_type { get; set; }
    }
}