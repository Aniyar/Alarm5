﻿namespace ALARm.Core
{
    public class RailsSections : MainTrackObject
    {
        public int Type_Id { get; set; }
        public string Type { get; set; }
    }
}