﻿namespace ALARm.Core
{
    public class ProfileObject : MainTrackObject
    {
        public int Km { get; set; }
        public int Meter { get; set; }
        public int Object_id { get; set; }
        public string Object_type { get; set; }
        public int Side_id { get; set; }
        public string Side { get; set; }
    }
}
