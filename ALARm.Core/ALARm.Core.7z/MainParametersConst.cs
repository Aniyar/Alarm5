﻿namespace ALARm.Core
{
    public class MainParametersConst
    {
        public const double koef_dropdown = 0.9;
        public const double koef_straightening = 1;   
    }
}