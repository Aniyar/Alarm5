﻿namespace ALARm.Core
{
    public class LongRails : MainTrackObject
    {
        public int Type_id { get; set; }
        public string Type { get; set; }
    }
}