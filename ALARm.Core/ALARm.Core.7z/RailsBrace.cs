﻿namespace ALARm.Core
{
    public class RailsBrace : MainTrackObject
    {
        public int Brace_Type_Id { get; set; }
        public string Brace_Type { get; set; }
    }
}