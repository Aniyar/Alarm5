﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALARm.Core
{
    public class PicketSpeed
    {
        public int Meter { get; set; }
        public int V11 { get; set; }
        public int V12 { get; set; }
        public int V21 { get; set; }
        public int V22 { get; set; }
    }
}
