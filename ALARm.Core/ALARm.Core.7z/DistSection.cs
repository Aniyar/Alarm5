﻿using System;

namespace ALARm.Core
{
    public class DistSection : MainTrackObject {
        public Int64 DistanceId { get; set; }
        public string Road { get; set; }
        public string Distance { get; set; }
    }
}