﻿namespace ALARm.Core
{
    public class TempSpeed : Speed
    {
        public int Reason_Id { get; set; }
        public string Reason { get; set; }
    }
}