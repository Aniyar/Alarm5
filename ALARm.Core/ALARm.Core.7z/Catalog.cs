﻿namespace ALARm.Core
{
    public class Catalog
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Mark { get; set; }
    }
}