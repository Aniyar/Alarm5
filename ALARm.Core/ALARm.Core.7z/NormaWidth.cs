﻿namespace ALARm.Core
{
    public class NormaWidth : MainTrackObject
    { 
        public int Norma_Width { get; set;}
    }
}